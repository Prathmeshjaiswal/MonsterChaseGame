using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveforce = 10f;
    public float jumpforce = 12f;

    public Rigidbody2D mybody;
    public SpriteRenderer sr;
    public float movementX;
    private Animator anim;
    private string WALK_ANIMATION = "Walk";
    private bool isGrounded = true;
    private string Ground_Tag = "Ground";
    private string Enemy_Tag = "Enemy";


    private void Awake(){
        anim = GetComponent<Animator>();
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMoveKeyboard();
        AnimatePlayer();
    }
    private void FixedUpdate()
    {
        JumpPlayer();
    }

     void PlayerMoveKeyboard(){
        movementX  = Input.GetAxisRaw("Horizontal");
        transform.position += new Vector3(movementX,0f,0f) * Time.deltaTime * moveforce;
    }

     void AnimatePlayer(){
        if (movementX > 0){
         anim.SetBool(WALK_ANIMATION, true);
         sr.flipX = false;
        }

        else if (movementX < 0){
         anim.SetBool(WALK_ANIMATION, true);
         sr.flipX = true;
            }

        else{
            anim.SetBool(WALK_ANIMATION,false);
        }
}
     void JumpPlayer(){
        if(Input.GetButton("Jump") && isGrounded){
            mybody.AddForce(new Vector2(0f,jumpforce), ForceMode2D.Impulse);
            isGrounded = false;
        }

     }

     private void OnCollisionEnter2D(Collision2D collision){
        if(collision.gameObject.CompareTag(Ground_Tag)){
            isGrounded = true;
        }

        if(collision.gameObject.CompareTag(Enemy_Tag)){
            Destroy(gameObject);
        }

     }


}

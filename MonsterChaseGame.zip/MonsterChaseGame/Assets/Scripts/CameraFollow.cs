using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    private Transform Player;
    private Vector3 tempos;
    [SerializeField]
    private int minx, maxx;

    void Start()
    {
        Player = GameObject.FindWithTag("Player").transform;
        // Debug.Log("selected character is " + GameManager.instance.CharIndex);
    }
    void LateUpdate()
    {
        if(!Player){
            return;
        }
        tempos = transform.position;
        tempos.x = Player.position.x;
        

        if(tempos.x<minx)
        tempos.x = minx;

        if(tempos.x>maxx)
        tempos.x = maxx;


        transform.position = tempos;
    }
}

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MonsterSpawner : MonoBehaviour
{
    [SerializeField]
    private GameObject[] monsterReference;

    public Transform leftpos, rightpos;
    private int randomindex;
    private int randomside;
    private GameObject SpawnedMonster;
    

    private void Awake(){
        SpawnedMonster = GetComponent<GameObject>();
    }
    void Start()
    {
        StartCoroutine(SpawnMonsters());
    }


    IEnumerator SpawnMonsters(){
        while(true){
            yield return new WaitForSeconds(Random.Range(1,5));
        randomindex = Random.Range(0,monsterReference.Length);
        randomside = Random.Range(0,2);
        SpawnedMonster = Instantiate(monsterReference[randomindex]);

        if(randomside == 0){
        SpawnedMonster.transform.position = leftpos.position;
        SpawnedMonster.GetComponent<Monsters>().speed = Random.Range(4,10);
    }

    else{
        SpawnedMonster.transform.position = rightpos.position;
        SpawnedMonster.GetComponent<Monsters>().speed = -Random.Range(4,10);
        SpawnedMonster.transform.localScale = new Vector3(-1f,1f,1f);
    }
    }
        }

    
}

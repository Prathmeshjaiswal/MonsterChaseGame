using UnityEngine;
using UnityEngine.UIElements;

public class MainMenuController : MonoBehaviour
{
    public VisualElement ui;

    public void Awake(){
         ui = GetComponent<UIDocument>().rootVisualElement;
    }
    private void OnEnable(){

         Button player1 = ui.Q<Button>("Player1");
         player1.clicked += OnPlayer1buttonClicked;


        //  Button Player2 = ui.Q<Button>("Player2");

         
    }

    private void OnPlayer1buttonClicked(){
        Debug.Log("Player1 is clicked");
    }

}

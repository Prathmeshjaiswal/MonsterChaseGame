using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    private Transform Player;
    private Vector3 tempos;
    [SerializeField]
    private int minx, maxx;

    void Start()
    {
        Player = GameObject.FindWithTag("Player").transform;
    }
    void LateUpdate()
    {
        if(!Player){
            return;
        }
        tempos = transform.position;
        

        if(tempos.x<minx)
        tempos.x = minx;

        else if(tempos.x>maxx)
        tempos.x = maxx;

        else 
        tempos.x = Player.position.x;

        transform.position = tempos;
    }
}

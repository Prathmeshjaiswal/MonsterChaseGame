using UnityEngine;

public class Monsters : MonoBehaviour
{
    public Rigidbody2D mybody;

    [HideInInspector]
    public float speed;

    private void Awake(){
        mybody = GetComponent<Rigidbody2D>();
    }


    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        mybody.linearVelocity = new Vector2(speed,mybody.linearVelocity.y);
    }
}

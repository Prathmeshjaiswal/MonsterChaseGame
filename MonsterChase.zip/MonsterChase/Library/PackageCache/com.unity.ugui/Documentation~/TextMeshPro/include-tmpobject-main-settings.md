## Main Settings

The Main Settings section contains the properties needed to define the basic appearance of text. You can further customize the look of text by changing or editing its [material](Shaders.md).
# System requirements

The Unity Multiplayer Center package is compatible with the following versions of the Unity Editor:
- Unity 6 beta and later
